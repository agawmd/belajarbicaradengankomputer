/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_pack;
/**
 *
 * @author aga
 */
public class Skypion_Project {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }
    
}
