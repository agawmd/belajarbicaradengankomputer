/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package class_pack;

import javax.swing.JOptionPane;

/**
 *
 * @author aga
 */
public class Confrim {
    
    public static void main (String[] args) {
        int firm = JOptionPane.showConfirmDialog(null, "Do you want to Logout?");
    }
    
    
}
