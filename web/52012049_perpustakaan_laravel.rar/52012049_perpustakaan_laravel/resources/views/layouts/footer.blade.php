<!--Footer-->
<footer id="footer" class="footer">
    <div class="container">
        <div class="row">
            <div class="footer-wrapper">

                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="footer-brand">
                        <img src="" />
                    </div>
                </div>

                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="copyright">
                        <p class="text-muted">&copy; 2016 WaodeMakaniDaga. All rights reserved.</p>
                    </div>
                </div>

            </div>
        </div>
    </div>
</footer>


<div class="scrollup">
    <a href="#"><i class="fa fa-chevron-up"></i></a>
</div>

