<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TugasAplikasi extends Model
{
    //
        protected $table = "aplikasi";

}
