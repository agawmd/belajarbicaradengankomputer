<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ilmiah extends Model
{
    protected $table = "ilmiah";
}
