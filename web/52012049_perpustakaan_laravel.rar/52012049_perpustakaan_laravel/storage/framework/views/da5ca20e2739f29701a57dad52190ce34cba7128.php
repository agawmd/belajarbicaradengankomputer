<?php $__env->startSection('content'); ?> 

<div class="container">
    <div class="row margin-top-40">
        <?php if(session()->has('status')): ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="alert alert-<?php echo e(session()->get('status')); ?> fade in alert-dismissable text-center">
                <?php echo session()->get('pesan'); ?>

            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
        <div class="col-md-12 text-center" >
            <a class="btn btn-success" href="<?php echo e(route('aplikasi.add')); ?>" float="left">Tambah Tugas Aplikasi</a>
        </div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="table-responsive"> 
                <table class="table" align="center" width='100%'>
                    <thead>
                        <tr class="tr-head">
                            <th>Judul</th>
                            <th>Nomor Induk Mahasiswa</th>
                            <th>Nama Mahasiswa</th>
                            <th>Jurusan</th>
                            <th>Tahun</th>
                            <?php if(auth()->guard()->check()): ?>
                            <th align="center">Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftarBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aplikasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($aplikasi->judul); ?></td>
                            <td><?php echo e($aplikasi->nim); ?></td>
                            <td><?php echo e($aplikasi->nama); ?></td>
                            <td><?php echo e($aplikasi->jurusan); ?></td>
                            <td><?php echo e($aplikasi->tahun); ?></td>
                            <?php if(auth()->guard()->check()): ?>
                            <td class="text-center">
                                <a class="icon-action" href="<?php echo e(route('aplikasi.edit', $aplikasi->id)); ?>">
                                    <i class="fa fa-pencil"></i> <!--Edit-->
                                </a>
                                &nbsp;
                                <a class="icon-action" href="<?php echo e(route('aplikasi.hapus', $aplikasi->id)); ?>">
                                    <i class="fa fa-trash"></i> <!--Hapus-->
                                </a>
                            </td>
                            <?php endif; ?>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>