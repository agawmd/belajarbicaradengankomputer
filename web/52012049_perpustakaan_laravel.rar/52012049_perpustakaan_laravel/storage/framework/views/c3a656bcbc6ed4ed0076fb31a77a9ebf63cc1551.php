<?php $__env->startSection('content'); ?>
<div class="container margin-bottom-80">
    <div class="row">
        <?php if(session()->has('status')): ?>
        <div class="col-md-12">
            <div class="alert alert-<?php echo e(session()->get('status')); ?> fade in alert-dismissable">
                <?php echo session()->get('pesan'); ?>

            </div>
        </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(isset($aplikasi) ? route('aplikasi.update', $aplikasi->id) : route('aplikasi.save')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-12 margin-top-20">
                <h5 align="center"><b>Tambah Tugas Aplikasi</b></h5>
            </div>
            <div class="col-md-6 col-md-offset-3  table-responsive">
                <table class="table">
                    <tr class="tr-head">
                        <th colspan="2">Detail Tugas Aplikasi</th>
                    </tr>                                                
                    <tr>
                        <td><b><i class="fa fa-book"></i> Judul</b></td>
                        <td><input class="form-control" name="judul" placeholder="Judul" value="<?php echo e(isset($aplikasi->judul) ? $aplikasi->judul : old('judul')); ?>"></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-user"></i> Nim</b></td>
                        <td><input class="form-control" name="nim" placeholder="Nomor Induk Mahasiswa" value="<?php echo e(isset($aplikasi->nim) ? $aplikasi->nim : old('nim')); ?>"></td>
                    </tr>                    
                    <tr>
                        <td><b><i class="fa fa-id-card"></i> Nama Mahasiswa</b></td>
                        <td><input class="form-control" name="nama" placeholder="Nama Mahasiswa" value="<?php echo e(isset($aplikasi->nama) ? $aplikasi->nama : old('nama')); ?>"></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-users"></i> Pembimbing</b></td>
                        <td><input class="form-control" name="pembimbing" placeholder="Pembimbing" value="<?php echo e(isset($aplikasi->pembimbing) ? $aplikasi->pembimbing : old('pembimbing')); ?>"></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-university"></i> Jurusan</b></td>
                        <td><input class="form-control" name="jurusan" placeholder="Jurusan" value="<?php echo e(isset($aplikasi->jurusan) ? $aplikasi->jurusan : old('jurusan')); ?>"></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-globe"></i> Tahun</b></td>
                        <td><input class="form-control" name="tahun" placeholder="Tahun" type="number" value="<?php echo e(isset($aplikasi->tahun) ? $aplikasi->tahun : old('tahun')); ?>"></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-plus-square"></i> Jumlah</b></td>
                        <td><input class="form-control" name="jumlah" placeholder="Jumlah" type="number" value="<?php echo e(isset($aplikasi->jumlah) ? $aplikasi->jumlah : old('jumlah')); ?>"></td>
                    </tr>
                </table>
            </div>
            <hr>            
            <div class="col-md-6 col-md-offset-3 margin-bottom-60">
                <a class="btn btn-danger" href="<?php echo e(route('home.aplikasi')); ?>">Batal</a>
                <input type="submit" value="Simpan" class="btn btn-success float-right">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>