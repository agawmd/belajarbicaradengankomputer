<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <form method="post" action="<?php echo e(route('buku.kembali.simpan', $detailPeminjaman->id)); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="col-md-12 margin-top-40">
                <h5 align="center">Pengembalian Buku</h5>
            </div>
            <div class="col-md-6 col-md-offset-3 table-responsive">
                <table class="table">
                    <tr class="tr-head">
                        <th colspan="2">Detail Buku</th>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-book"></i> Judul</b></td>
                        <td><?php echo e($detailPeminjaman->detailBuku->judul); ?></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-users"></i> Pengarang</b></td>
                        <td><?php echo e($detailPeminjaman->detailBuku->pengarang); ?></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-building"></i> Penerbit</b></td>
                        <td><?php echo e($detailPeminjaman->detailBuku->penerbit); ?></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-globe"></i> Tahun</b></td>
                        <td><?php echo e($detailPeminjaman->detailBuku->tahun); ?></td>
                    </tr>
                    <tr class="tr-head">
                        <th colspan="2">Detail Peminjam</th>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-user"></i> Nim</b></td>
                        <td><?php echo e($detailPeminjaman->nim); ?></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-calendar"></i> Tanggal Peminjaman</b></td>
                        <td><?php echo e($detailPeminjaman->tgl_pinjam); ?></td>
                    </tr>

                    <tr>
                        <td><b><i class="fa fa-clock-o"></i> Lama Peminjaman</b></td>
                        <td><?php echo e($detailPeminjaman->lama_pinjam); ?></td>
                    </tr>
                    <tr>
                        <td><b><i class="fa fa-calendar"></i> Tanggal Kembali</b></td>
                        <td><input class="form-control" name="tgl_kembali" type="date" value="<?php echo e(date('Y-m-d')); ?>" max="<?php echo e(date('Y-m-d')); ?>" ></td>
                    </tr>
                </table>
                <hr>
            </div>

            <div class="col-md-6 col-md-offset-3 margin-bottom-60">
                <a class="btn btn-danger" href="<?php echo e(route('buku.kembali')); ?>">Batal</a>
                <input type="submit" value="Kembalikan Sekarang" class="btn btn-success float-right">
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>