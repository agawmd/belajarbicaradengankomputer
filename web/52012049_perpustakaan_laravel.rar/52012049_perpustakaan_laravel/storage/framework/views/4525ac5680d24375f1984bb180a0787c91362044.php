<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <?php if(auth()->guard()->check()): ?>
        <div class="col-md-12 text-center" >
            <a class="btn btn-success" href="<?php echo e(route('jurnal.add')); ?>">Tambah Journal/Prociding</a>
        </div>
        <?php endif; ?>

        <table align="center">
            <thead>
                <tr class="tr-head">
                    <th>Judul</th>
                    <th>Penulis</th>
                    <th>Penerbit</th>
                    <th>Jurnal</th>
                    <th>Bidang Ilmu</th>
                    <th>Volume</th>
                    <th>Edisi</th>
                    <th>Kota</th>
                    <th>Tahun</th>
                    <?php if(auth()->guard()->check()): ?>
                    <th>Aksi</th>
                    <?php endif; ?>
                    
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $daftarBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurnal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($jurnal->judul); ?></td>
                    <td><?php echo e($jurnal->penulis); ?></td>
                    <td><?php echo e($jurnal->bidang); ?></td>
                    <td><?php echo e($jurnal->penerbit); ?></td>
                    <td><?php echo e($jurnal->volume); ?></td>
                    <td><?php echo e($jurnal->edisi); ?></td>
                    <td><?php echo e($jurnal->kota); ?></td>
                    <td><?php echo e($jurnal->tahun); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>