<?php $__env->startSection('content'); ?>       

<div class="container">
    <div class="row margin-top-40">
        <?php if(session()->has('status')): ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="alert alert-<?php echo e(session()->get('status')); ?> fade in alert-dismissable text-center">
                <?php echo session()->get('pesan'); ?>

            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
        <div class="col-md-12 row" >
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <a class="btn btn-success" href="<?php echo e(route('buku.add')); ?>" float="left">Tambah Buku</a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <a class="btn btn-warning float-right" href="<?php echo e(route('buku.kembali')); ?>">Pengembalian Buku</a>
            </div>
        </div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="table-responsive">

                <table class="table" align="center" width='100%'>
                    <thead>
                    <tr class="tr-head">
                        <th>Judul</th>
                        <th>Pengarang</th>
                        <th>Penerbit</th>
                        <th>Jumlah Buku</th>
                        <th>Tahun</th>
                        <?php if(auth()->guard()->check()): ?>
                        <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftarBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($buku->judul); ?></td>
                            <td><?php echo e($buku->pengarang); ?></td>
                            <td><?php echo e($buku->penerbit); ?></td>
                            <td><?php echo e($buku->jumlah); ?></td>
                            <td><?php echo e($buku->tahun); ?></td>
                            <?php if(auth()->guard()->check()): ?>
                            <td>
                                <a class="icon-action" href="<?php echo e(route('buku.pinjam', $buku->id)); ?>">
                                    <i class="fa fa-thumbs-o-up"></i> <!--Pinjam-->
                                </a>
                                &nbsp;
                                <a class="icon-action" href="<?php echo e(route('buku.edit', $buku->id)); ?>">
                                    <i class="fa fa-pencil"></i> <!--Edit-->
                                </a>
                                &nbsp;
                                <a class="icon-action" href="<?php echo e(route('buku.hapus', $buku->id)); ?>">
                                    <i class="fa fa-trash"></i> <!--Hapus-->
                                </a>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>