<?php $__env->startSection('content'); ?>       
<?php if(auth()->guard()->check()): ?>
<div class="container">
    <div class="row margin-top-40">
        <?php if(session()->has('status')): ?>
        <div class="col-md-8 col-md-offset-2">
            <div class="alert alert-<?php echo e(session()->get('status')); ?> fade in alert-dismissable text-center">
                <?php echo session()->get('pesan'); ?>

            </div>
        </div>
        <?php endif; ?>
        <div class="col-md-12">
            <div class="col-md-12 margin-top-20">
                <h5 align="center"><b>Daftar Peminjaman Buku</b></h5>
            </div>
            <div clas="col-md-12">
                <div class="table-responsive">

                    <table class="table" align="center" width='100%'>
                        <thead>
                            <tr class="tr-head">
                                <th>ID Peminjaman</th>
                                <th>Nim</th>
                                <th>Tanggal Peminjaman</th>
                                <th>Judul</th>
                                <th>Pengarang</th>
                                <th>Penerbit</th>
                                <th>Tahun</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $daftarPeminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th align="center"><?php echo e($pinjam->id); ?></th>
                                <td><?php echo e($pinjam->nim); ?></td>
                                <td><?php echo e($pinjam->tgl_pinjam); ?></td>
                                <td><?php echo e($pinjam->detailBuku->judul); ?></td>
                                <td><?php echo e($pinjam->detailBuku->pengarang); ?></td>
                                <td><?php echo e($pinjam->detailBuku->penerbit); ?></td>
                                <td><?php echo e($pinjam->detailBuku->tahun); ?></td>
                                <td>
                                    <a href="<?php echo e(route('buku.kembali.detail', $pinjam->id)); ?>">Kembalikan</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>