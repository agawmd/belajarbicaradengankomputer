//package server;

import java.io.*;
import java.net.*;

public class ServerKurang {

	public static void main (String args[]) {
		new ServerKalkulator('-', 5556).start();
	}
}