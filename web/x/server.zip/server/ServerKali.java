//package server;

import java.io.*;
import java.net.*;

public class ServerKali {

	public static void main (String args[]) {
		new ServerKalkulator('*', 5557).start();
	}
}