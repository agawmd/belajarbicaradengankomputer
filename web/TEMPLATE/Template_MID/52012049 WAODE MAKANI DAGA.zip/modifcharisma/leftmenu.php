<!-- left menu starts -->
<div class="col-sm-2 col-lg-2">
    <div class="sidebar-nav">
        <div class="nav-canvas">
            <div class="nav-sm nav nav-stacked">

            </div>
            <ul class="nav nav-pills nav-stacked main-menu">
                <li class="nav-header">Main</li>
                <li><a class="ajax-link" href="index.php"><i class="glyphicon glyphicon-home"></i><span> Dashboard</span></a>
                </li>
                <li><a class="ajax-link" href="index.php?hal=3"><i
                            class="glyphicon glyphicon-edit"></i><span> Tambah Data</span></a></li>
                <li><a class="ajax-link" href="index.php?hal=2"><i
                            class="glyphicon glyphicon-align-justify"></i><span> Lihat Data</span></a></li>
                <li><a href="login.html"><i class="glyphicon glyphicon-lock"></i><span> Login Page</span></a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!--/span-->
<!-- left menu ends -->
